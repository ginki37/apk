package com.ai3dstudio.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.ai3dstudio.mobile.navigation.AiStudioNavHost
import com.ai3dstudio.mobile.ui.theme.AI3DStudioTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AiStudioRoot()
        }
    }
}

@Composable
private fun AiStudioRoot() {
    AI3DStudioTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            AiStudioNavHost()
        }
    }
}
